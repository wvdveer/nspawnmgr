#ifndef WINPR_BUILD_FLAGS_H
#define WINPR_BUILD_FLAGS_H

#define WINPR_CFLAGS " -Wall -Wpedantic -Wno-padded -Wno-cast-align -Wno-declaration-after-statement -fPIC -Wall -fvisibility=hidden -Wimplicit-function-declaration -Wredundant-decls -g -fno-omit-frame-pointer -DWINPR_DLL"
#define WINPR_COMPILER_ID "GNU"
#define WINPR_COMPILER_VERSION "12.2.0"
#define WINPR_TARGET_ARCH "x64"
#define WINPR_BUILD_CONFIG ""
#define WINPR_BUILD_TYPE ""

#endif /* WINPR_BUILD_FLAGS_H */
