/**
 * FreeRDP: A Remote Desktop Protocol Implementation
 * Audio Virtual Channel Types
 *
 * Copyright 2012 Vic Lee
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *	 http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef FREERDP_CHANNEL_RDPSND_H
#define FREERDP_CHANNEL_RDPSND_H

#include <freerdp/api.h>
#include <freerdp/types.h>

#include <freerdp/codec/audio.h>

#define RDPSND_CHANNEL_NAME "rdpsnd"
#define RDPSND_DVC_CHANNEL_NAME "AUDIO_PLAYBACK_DVC"
#define RDPSND_LOSSY_DVC_CHANNEL_NAME "AUDIO_PLAYBACK_LOSSY_DVC"

#endif /* FREERDP_CHANNEL_RDPSND_H */
